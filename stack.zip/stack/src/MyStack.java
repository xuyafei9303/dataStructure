/**
 * 栈
 * 用数组实现
 */
public class MyStack {

    private int[] array;
    private int maxSize;
    private int top;

    public MyStack(int size) {
        this.maxSize = size;
        array = new int[size];
        top = -1;
    }

    // 压入数据
    public void push(int value) {
        if (top < maxSize) {
            array[++top] = value;
        }
    }

    // 弹出栈顶数据
    public int pop() {
        return array[top--];
    }

    // 访问栈顶数据
    public int peek() {
        return array[top];
    }

    // 判断栈顶是否为空
    public boolean isEmpty() {
        return (top == -1);
    }

    // 判断栈顶是否满了
    public boolean isFull() {
        return (top == maxSize);
    }
}

/**
 * 产生的问题：
 *
 * 　　①、上面栈的实现初始化容量之后，后面是不能进行扩容的（虽然栈不是用来存储大量数据的），如果说后期数据量超过初始容量之后怎么办？（自动扩容）
 *
 * 　　②、我们是用数组实现栈，在定义数组类型的时候，也就规定了存储在栈中的数据类型，那么同一个栈能不能存储不同类型的数据呢？（声明为Object）
 *
 * 　　③、栈需要初始化容量，而且数组实现的栈元素都是连续存储的，那么能不能不初始化容量呢？
 */
