package com.ixyf.tree;

/**
 * 二叉树的具体实现类
 */
public class TreeImpl implements Tree{

    private Node root; // 表示根节点

    /**
     * 查找节点
     *
     * 查找某个节点，我们必须从根节点开始遍历。
     *
     * ①、查找值比当前节点值大，则搜索右子树；
     *
     * ②、查找值等于当前节点值，停止搜索（终止条件）；
     *
     * ③、查找值小于当前节点值，则搜索左子树；
     *
     * @param key
     * @return
     */
    @Override
    public Node find(int key) {
        Node current = root;
        while (current != null) {
            if (current.data > key) { // 当前值比查找值达，搜索左子树
                current = current.leftChild;
            } else if (current.data < key) { // 当前值比查找值小，搜索右子树
                current = current.rightChild;
            } else {
                return current;
            }
        }
        return null; // 遍历整个树没找到，返回null
    }

    /**
     * 插入节点
     *
     * 要插入节点，必须先找到插入的位置。
     * 与查找操作相似，由于二叉搜索树的特殊性，待插入的节点也需要从根节点开始进行比较，小于根节点则与根节点左子树比较，
     * 反之则与右子树比较，直到左子树为空或右子树为空，则插入到相应为空的位置，
     * 在比较的过程中要注意保存父节点的信息 及 待插入的位置是父节点的左子树还是右子树，才能插入到正确的位置
     * @param data
     * @return
     */
    @Override
    public boolean insert(int data) {
        Node newData = new Node(data);
        if (root == null) {// 当前树为空树，没有任何节点
            root = newData;
            return true;
        } else {
            Node current = root;
            Node parentNode = null;
            while (current != null) {
                parentNode = current;
                if (current.data > data) { // 当前值比插入值达，搜索左子节点
                    current = current.leftChild;
                    if (current == null) { // 左子节点为空，直接将新值插入到该节点
                        parentNode.leftChild = newData;
                        return true;
                    }
                } else {
                    current = current.rightChild;
                    if (current == null) { // 右子节点为空，直接将新值插入到该节点
                        parentNode.rightChild = newData;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * 删除节点
     *
     * 删除节点是二叉搜索树中最复杂的操作，删除的节点有三种情况，前两种比较简单，但是第三种却很复杂。
     *
     * 1、该节点是叶节点（没有子节点）
     *
     * 2、该节点有一个子节点
     *
     * 3、该节点有两个子节点
     *
     * 下面我们分别对这三种情况进行讲解：
     *
     * ①、删除没有子节点的节点
     *
     * 要删除叶节点，只需要改变该节点的父节点引用该节点的值，即将其引用改为 null 即可。
     * 要删除的节点依然存在，但是它已经不是树的一部分了，由于Java语言的垃圾回收机制，我们不需要非得把节点本身删掉，
     * 一旦Java意识到程序不在与该节点有关联，就会自动把它清理出存储器
     *
     *
     * 删除节点，我们要先找到该节点，并记录该节点的父节点。在检查该节点是否有子节点。
     * 如果没有子节点，接着检查其是否是根节点，如果是根节点，只需要将其设置为null即可。
     * 如果不是根节点，是叶节点，那么断开父节点和其的关系即可
     * @param key
     * @return
     */
    @Override
    public boolean delete(int key) {
        Node current = root;
        Node parent = root;
        boolean isLeftChild = false;
        /**
         * 查找删除值，找不到直接返回false
         */
        while (current.data != key) {
            parent = current;
            if (current.data > key) {
                isLeftChild = true;
                current = current.leftChild;
            } else {
                isLeftChild = false;
                current = current.rightChild;
            }
            if (current == null) {
                return false;
            }
        }

        /**
         * 如果当前节点没有子节点
         */
        if (current.leftChild == null && current.rightChild == null) {
            if (current == root) {
                root = null;
            } else if (isLeftChild) {
                parent.leftChild = null;
            } else {
                parent.rightChild = null;
            }
            return true;

            /**
             * 当前节点只有一个子节点 右子节点
             */
        } else if (current.leftChild == null && current.rightChild != null) {
            if (current == root) {
                root = current.rightChild;
            } else if (isLeftChild) {
                parent.leftChild = current.rightChild;
            } else {
                parent.rightChild = current.rightChild;
            }
            return true;
            /**
             * 当前节点只有一个子节点，左子节点
             */
        } else if (current.leftChild != null && current.rightChild == null){
            if (current == root) {
                root = current.leftChild;
            } else if (isLeftChild) {
                parent.leftChild = current.leftChild;
            } else {
                parent.rightChild = current.leftChild;
            }
            return true;
        } else {
            /**
             * 当前节点存在两个子节点
             *
             * 删除节点以后，存在的子节点怎么处理：
             *  用另一个节点来代替被删除的节点
             *
             * 如何找这个代替节点：
             *  寻找比被删除的节点大的所有节点，然后让其中最小的一个当做替代节点 -> (比删除节点大的最小节点)
             *
             *  算法：程序找到删除节点的右节点，(注意这里前提是删除节点存在左右两个子节点，如果不存在则是删除情况的前面两种)，
             *      然后转到该右节点的左子节点，依次顺着左子节点找下去，最后一个左子节点即是后继节点；
             *      如果该右节点没有左子节点，那么该右节点便是后继节点
             *
             *  需要确定后继节点没有子节点，如果后继节点存在子节点，那么又要分情况讨论了:
             *
             *  1.后继节点实时喊出节点的右子节点
             *      这种情况简单，只需要将后继节点表示的子树移到被删除节点的位置即可！
             *
             *  2.后继节点是删除节点的右子节点的左子节点
             *
             */
            Node successor = getSuccessor(current);
            if (current == root) {
                successor = root;
            } else if (isLeftChild) {
                parent.leftChild = successor;
            } else {
                parent.rightChild = successor;
            }
            successor.leftChild = current.leftChild;
        }
        return false;
    }

    public Node getSuccessor(Node delNode) {

        Node successorParent = delNode;
        Node successor = delNode;
        Node current = delNode.rightChild;

        while (current != null) {
            successorParent = successor;
            successor = current;
            current = current.leftChild;
        }

        // 将后继节点替换删除节点
        if (successor != delNode.rightChild) {
            successorParent.leftChild = successor.rightChild;
            successor.rightChild = delNode.rightChild;
        }
        return successor;
    }

    /**
     * 中序遍历
     * @param current
     */
    @Override
    public void infixOrder(Node current) {

        if (current != null) {
            infixOrder(current.leftChild);
            System.out.print(current.data + " ");
            infixOrder(current.rightChild);
        }

    }

    /**
     * 前序遍历
     * @param current
     */
    @Override
    public void preOrder(Node current) {

        if (current != null) {
            System.out.print(current.data + " ");
            infixOrder(current.leftChild);
            infixOrder(current.rightChild);
        }
    }

    /**
     * 后序遍历
     * @param current
     */
    @Override
    public void postOrder(Node current) {

        if (current != null) {
            infixOrder(current.leftChild);
            infixOrder(current.rightChild);
            System.out.print(current.data + " ");
        }
    }

    /**
     * 找到最大值
     * @return
     */
    @Override
    public Node findMax() {

        Node current = root;
        Node maxNode = current;
        while (current != null) {
            maxNode = current;
            current = current.rightChild;
        }
        return maxNode;
    }

    @Override
    public Node findMin() {
        Node current = root;
        Node minNode = current;
        while (current != null) {
            minNode = current;
            current = current.leftChild;
        }
        return minNode;
    }
}
