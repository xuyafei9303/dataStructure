package com.ixyf.tree;

public class Main {

    public static void main(String[] args) {
	// write your code here

        TreeImpl ti = new TreeImpl();
        ti.insert(50);
        ti.insert(20);
        ti.insert(80);
        ti.insert(10);
        ti.insert(30);
        ti.insert(60);
        ti.insert(90);
        ti.insert(25);
        ti.insert(85);
        ti.insert(100);

        ti.delete(10);// 删除没有子节点的节点
        ti.delete(30);// 删除有一个子节点的节点
        ti.delete(80);// 删除有两个子节点的节点

        System.out.println(ti.findMax().data);
        System.out.println(ti.findMin().data);

        System.out.println(ti.find(100));
        System.out.println(ti.find(200));
    }
}
