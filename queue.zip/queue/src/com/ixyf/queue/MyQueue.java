package com.ixyf.queue;
/**
 * 队列 queue
 * 特点：队列只允许在表的前端进行删除操作，在表的后端进行插入操作，和栈一样，是一种操作受限制的线性表
 * 进行插入操作的端称为队尾，删除操作的端叫做队头
 * 没有元素的时候叫空队列
 *
 * 队列元素
 * 插入元素叫入队，删除叫做出队 --> 先进先出FIFO
 *
 * 单向队列：只能在一端插入数据，另一端删除数据
 * 双向队列：每一端都可以进行插入数据和删除数据
 *
 * 优先级队列：比队列和栈更加专用，在优先级队列中，数据项按照关键字进行排序，关键字最大的（最小的）往往排在队列的最前面，而数据项在插入的时候都会插入到合适的位置以确保队列的有序
 *
 * 双端队列：
 * 两端都是结尾或者开头，每一端都可以进行插入数据项和移除数据项
 * 方法：
 * insertRight()
 * insertLeft()
 * removeLeft()
 * removeRight()
 *
 * 如果严格禁止调用insertLeft()和removeLeft()（或禁用右端操作），那么双端队列的功能就和前面讲的栈功能一样。
 *
 * 如果严格禁止调用insertLeft()和removeRight(或相反的另一对方法)，那么双端队列的功能就和单向队列一样了。
 */
public class MyQueue {

    private Object[] queArray;

    // 总队列大小
    private int maxSize;
    // 前端
    private int front;
    // 后端
    private int rear;
    // 队列中元素的实际数目
    private int nItems;

    public MyQueue(int s) {
        maxSize = s;
        queArray = new Object[maxSize];
        front = 0;
        rear = -1;
        nItems = 0;
    }

    /**
     * 队列中新增数据
     */
    public void insert(int value) {
        if (isFull()) {
            System.out.println("队列已满！");
        } else {
            // 如果队列尾部指向顶了，那么循环回来，执行队列的第一个元素
            if (rear == maxSize-1) {
                rear = -1;
            }
            // 队尾指针加1，然后在队尾指针插入新的数据
            queArray[++rear] = value;
            nItems++;
        }
    }

    /**
     * 移除数据
     */
    public Object remove() {
        Object removeValue = null;
        if (!isEmpty()) {
            removeValue = queArray[front];
            queArray[front] = null;
            front++;
            if (front == maxSize) {
                front = 0;
            }
            nItems--;
            return removeValue;
        }
        return removeValue;
    }

    /**
     * 查看对头数据
     */
    public Object peekFront() {
        return queArray[front];
    }

    /**
     * 判断队列是否满了
     */
    public boolean isFull() {
        return (nItems == maxSize);
    }

    /**
     * 判断队列是否为空
     */
    public boolean isEmpty() {
        return (nItems == 0);
    }

    /**
     * 返回队列的大小
     */
    public int getSize() {
        return nItems;
    }
}
