package com.ixyf.linkedList;

public class Main {

    public static void main(String[] args) {
	// write your code here

        SingleLinkedList singleLinkedList = new SingleLinkedList();
        singleLinkedList.addHead("A");
        singleLinkedList.addHead("B");
        singleLinkedList.addHead("C");
        singleLinkedList.addHead("D");

        singleLinkedList.display();

        singleLinkedList.delete("C");
        singleLinkedList.display();

        System.out.println(singleLinkedList.find("B"));
    }
}
