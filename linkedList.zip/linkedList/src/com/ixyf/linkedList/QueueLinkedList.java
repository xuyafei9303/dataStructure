package com.ixyf.linkedList;

public class QueueLinkedList {

    private DoublePointLinkerList dp;

    public QueueLinkedList() {
        dp = new DoublePointLinkerList();
    }

    public void insert(Object data) {
        dp.addTail(data);
    }

    public void delete() {
        dp.deleteHead();
    }

    public boolean isEmpty() {
        return dp.isEmpty();
    }

    public int getSize() {
        return dp.getSize();
    }

    public void display() {
        dp.display();
    }
}

/**
 * 抽象数据类型
 *
 * 特征：
 * 1.拥有特定特征的数据项
 * 2.在数据上允许的操作
 *
 * 比如Java中的int数据类型，它表示整数，取值范围为：-2147483648~2147483647，
 * 还能使用各种操作符，+、-、*、/ 等对其操作。数据类型允许的操作是它本身不可分离的部分，理解类型包括理解什么样的操作可以应用在该类型上
 *
 *
 */
